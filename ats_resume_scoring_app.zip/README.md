# ATS Resume Scoring Tool

## Setup
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Usage
- Go to `http://127.0.0.1:8000`
- Upload a resume
- Optionally paste job description
- View ATS score and improvement insights

## Deployment
You can deploy on [Render.com](https://render.com/) or [Railway.app](https://railway.app/) for free.