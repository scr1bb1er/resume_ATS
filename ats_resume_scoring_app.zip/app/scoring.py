import re
from collections import Counter
import textstat

KEY_SECTIONS = ["experience", "education", "skills", "summary"]
ACTION_VERBS = ["led", "developed", "managed", "designed", "implemented", "created"]

def score_resume(resume_text, jd_text):
    text = resume_text.lower()
    score = 0
    max_score = 100

    section_score = sum(1 for s in KEY_SECTIONS if s in text)
    verb_count = sum(text.count(v) for v in ACTION_VERBS)
    readability = textstat.flesch_reading_ease(resume_text)

    jd_keywords = [w for w in re.findall(r"\w+", jd_text.lower()) if len(w) > 4]
    resume_words = Counter(re.findall(r"\w+", text))
    keyword_matches = sum(1 for w in jd_keywords if resume_words[w] > 0)

    keyword_score = (keyword_matches / len(jd_keywords)) * 25 if jd_keywords else 0
    final_score = min(100, section_score * 10 + verb_count * 2 + readability * 0.2 + keyword_score)

    return {
        "score": round(final_score, 1),
        "sections_found": section_score,
        "action_verbs": verb_count,
        "readability": round(readability, 1),
        "keyword_matches": keyword_matches,
        "jd_provided": bool(jd_text)
    }