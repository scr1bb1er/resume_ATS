import pdfplumber
from docx import Document
from io import BytesIO

def extract_text_from_file(filename, content_bytes):
    ext = filename.lower().split(".")[-1]
    if ext == "pdf":
        with pdfplumber.open(BytesIO(content_bytes)) as pdf:
            return "\n".join(page.extract_text() or "" for page in pdf.pages)
    elif ext == "docx":
        doc = Document(BytesIO(content_bytes))
        return "\n".join(p.text for p in doc.paragraphs)
    else:
        return "Unsupported file type"